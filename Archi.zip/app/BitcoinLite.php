<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BitcoinLite extends Model
{
    public $table = 'bitcoin_lites';
}

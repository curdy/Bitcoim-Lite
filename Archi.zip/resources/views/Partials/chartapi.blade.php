<div class="page-chatapi hideit">

        <div class="search-bar">
            <input type="text" placeholder="Search" class="form-control">
        </div>

        <div class="chat-wrapper">

            <h4 class="group-head">Favourites</h4>
            <ul class="contact-list">

            </ul>

            <h4 class="group-head">More Contacts</h4>
            <ul class="contact-list">

            </ul>
        </div>

    </div>

    <div class="chatapi-windows ">

    </div>
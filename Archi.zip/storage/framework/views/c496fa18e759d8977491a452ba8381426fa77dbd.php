<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" type="image/x-icon" />
    <!-- For iPhone -->
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('assets/images/apple-touch-icon-57-precomposed.png')); ?>">
    <!-- For iPhone 4 Retina display -->
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(asset('assets/images/apple-touch-icon-114-precomposed.png')); ?>">
    <!-- For iPad -->
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(asset('assets/images/apple-touch-icon-72-precomposed.png')); ?>">
    <!-- For iPad Retina display -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(asset('assets/images/apple-touch-icon-144-precomposed.png')); ?>">

    <!-- CORE CSS FRAMEWORK - START -->
    <link href="<?php echo e(asset('assets/plugins/pace/pace-theme-flash.css')); ?>" rel="stylesheet" type="text/css" media="screen" />
    <link href="<?php echo e(asset('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/bootstrap/css/bootstrap-theme.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/fonts/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/animate.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/perfect-scrollbar/perfect-scrollbar.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- CORE CSS FRAMEWORK - END -->

    <!-- HEADER SCRIPTS INCLUDED ON THIS PAGE - START -->

    <link href="<?php echo e(asset('assets/plugins/jquery-ui/smoothness/jquery-ui.min.css')); ?>" rel="stylesheet" type="text/css" media="screen" />
    <link href="<?php echo e(asset('assets/plugins/jvectormap/jquery-jvectormap-2.0.1.css')); ?>" rel="stylesheet" type="text/css" media="screen" />
    <link href="<?php echo e(asset('assets/plugins/icheck/skins/minimal/white.css')); ?>" rel="stylesheet" type="text/css" media="screen" />

    <!-- HEADER SCRIPTS INCLUDED ON THIS PAGE - END -->

    <!-- CORE CSS TEMPLATE - START -->
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- CORE CSS TEMPLATE - END -->

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</head>
<body>
        <!-- START TOPBAR -->
            <div class='page-topbar '>
                <?php echo $__env->make('Partials.topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        <!-- END TOPBAR -->
    
        <!-- START CONTAINER -->
            <div class="page-container row-fluid container-fluid">

                    <!-- SIDEBAR - START -->
                        <?php echo $__env->make('Partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!--  SIDEBAR - END -->

                <!-- START CONTENT -->
                    <?php echo $__env->yieldContent('content'); ?>
                <!-- END CONTENT -->

                <?php echo $__env->make('Partials.chartapi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            
        <!-- END CONTAINER -->
<!-- LOAD FILES AT PAGE END FOR FASTER LOADING -->

<!-- CORE JS FRAMEWORK - START -->
<script src="<?php echo e(asset('assets/js/jquery-1.11.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/pace/pace.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/viewport/viewportchecker.js')); ?>"></script>
<script>
        window.jQuery || document.write("<script src='<?php echo e(asset('assets/js/jquery-1.11.2.min.js')); ?>'><\/script>");
    </script>
<script>
    function myFunction(val){
                document.getElementById('put2').value = val;
            }        
</script>

<!-- CORE JS FRAMEWORK - END -->

<!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - START -->

<script src="<?php echo e(asset('assets/plugins/echarts/echarts-all.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/chart-echarts.js')); ?>"></script>
<!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - END -->

<!-- CORE TEMPLATE JS - START -->
<script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
<!-- END CORE TEMPLATE JS - END -->


</body>
</html>
